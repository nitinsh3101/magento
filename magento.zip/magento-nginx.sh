docker-compose up -d mysql
docker-compose up -d elasticsearch
docker-compose up -d magento
